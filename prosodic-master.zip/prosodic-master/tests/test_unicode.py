def test_nonsense():
    assert 1 == 1

# #encoding=utf-8

# import prosodic as p
# p.config['print_to_screen']=True

# input_text=u"""Let me not to the marriage of true minds
# Admit impediments. Love is not love
# Which alters when it alteration finds,
# Or bends with the remover to remove.
# O no, it is an ever-fixèd mark
# That looks on tempests and is never shaken;
# It is the star to every wand'ring bark,
# Whose worth's unknown, although his height be taken.
# Love's not Time's fool, though rosy lips and cheeks
# Within his bending sickle's compass come;
# Love alters not with his brief hours and weeks,
# But bears it out even to the edge of doom.
# If this be error and upon me proved,
# I never writ, nor no man ever loved."""

# # input_text is some string
# text = p.Text(input_text)
# text.parse()
